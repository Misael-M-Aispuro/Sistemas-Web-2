package com.tiendasara.Tienda.Sara;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaSaraApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaSaraApplication.class, args);
	}

}
